package com.mahir.shoytanishokti;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Random;

public class MainActivity extends Activity {

    private static final int REQ_FILE = 101;
    private static final int REQ_MEDIA = 102;
    private static final int REQ_PERM = 103;
    private static final long MAX_MEDIA_BYTES = 40L * 1024L * 1024L;
    private static final int CHUNK = 3 * 128 * 1024; // multiple of 3 -> clean base64 pieces

    private static final String APP_TITLE = "মাহির ব্রাউজার কল";

    private static final String[] SITE_NAMES = {
            "Facebook", "Messenger", "Instagram", "WhatsApp Web", "Telegram Web"
    };
    private static final String[] SITE_URLS = {
            "https://www.facebook.com/",
            "https://www.messenger.com/",
            "https://www.instagram.com/",
            "https://web.whatsapp.com/",
            "https://web.telegram.org/k/"
    };
    private static final String[] ALLOWED_HOSTS = {
            "facebook.com", "messenger.com", "instagram.com", "whatsapp.com", "telegram.org"
    };

    private SharedPreferences prefs;
    private File mixDir;

    private WebView web;
    private WebView panel;
    private FrameLayout panelBox;

    private boolean desktop;
    private String defaultUa;
    private String mixerState = "{\"items\":[],\"mics\":[],\"devices\":[]}";
    private long lastReady = 0;
    private boolean injectedThisLoad = false;
    private String injectJs = null;

    private PermissionRequest pendingRequest;
    private ValueCallback<Uri[]> pendingFile;

    private AudioManager audioManager;
    private AudioFocusRequest focusRequest;
    private final AudioManager.OnAudioFocusChangeListener focusListener =
            new AudioManager.OnAudioFocusChangeListener() {
                @Override
                public void onAudioFocusChange(int change) {
                    // Another app (e.g. the real Messenger app) took audio focus:
                    // do NOT pause, just keep our audio contexts alive.
                    resumeCallAudio();
                }
            };

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("PREFS", MODE_PRIVATE);
        mixDir = new File(getFilesDir(), "mixer");
        mixDir.mkdirs();
        desktop = prefs.getBoolean("desktop", false);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Color.parseColor("#04121a"));
        getWindow().setNavigationBarColor(Color.parseColor("#04121a"));

        buildUi();
        setupMainWebView();
        setupPanelWebView();

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_PERM + 1);
        }

        String start = prefs.getString("lastUrl", SITE_URLS[1]);
        web.loadUrl(start);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) {
            web.onResume();
            resumeCallAudio();
        }
    }

    @Override
    protected void onDestroy() {
        try {
            if (audioManager != null) {
                if (Build.VERSION.SDK_INT >= 26 && focusRequest != null) {
                    audioManager.abandonAudioFocusRequest(focusRequest);
                } else {
                    audioManager.abandonAudioFocus(focusListener);
                }
            }
        } catch (Exception ignored) {
        }
        if (web != null) web.destroy();
        if (panel != null) panel.destroy();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (panelBox.getVisibility() == View.VISIBLE) {
            hidePanel();
        } else if (web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }

    // ------------------------------------------------------------------ UI

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#04121a"));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);

        // ---- top bar: [☰]  মাহির ব্রাউজার কল
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(Color.parseColor("#08202c"));

        TextView menuBtn = new TextView(this);
        menuBtn.setText("☰");
        menuBtn.setTextSize(24);
        menuBtn.setTextColor(Color.parseColor("#5ff5d6"));
        menuBtn.setGravity(Gravity.CENTER);
        menuBtn.setPadding(dp(16), 0, dp(16), 0);
        menuBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showSites();
            }
        });
        bar.addView(menuBtn, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));

        TextView title = new TextView(this);
        title.setText(APP_TITLE);
        title.setTextSize(17);
        title.setTextColor(Color.WHITE);
        title.setSingleLine(true);
        bar.addView(title, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        col.addView(bar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(50)));

        web = new WebView(this);
        col.addView(web, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        root.addView(col, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // ---- panel (Mic / Mixer) shown below the top bar
        panelBox = new FrameLayout(this);
        panelBox.setBackgroundColor(Color.parseColor("#04121a"));
        panelBox.setVisibility(View.GONE);
        panel = new WebView(this);
        panelBox.addView(panel, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        TextView close = new TextView(this);
        close.setText("✕ বন্ধ");
        close.setTextSize(15);
        close.setTextColor(Color.WHITE);
        close.setPadding(dp(16), dp(10), dp(16), dp(10));
        close.setBackground(pill("#1c4456"));
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hidePanel();
            }
        });
        FrameLayout.LayoutParams closeLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.START);
        closeLp.setMargins(dp(16), 0, 0, dp(16));
        panelBox.addView(close, closeLp);

        FrameLayout.LayoutParams panelLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        panelLp.topMargin = dp(50);
        root.addView(panelBox, panelLp);

        // ---- floating 3-dot button, bottom right
        TextView fab = new TextView(this);
        fab.setText("⋮");
        fab.setTextSize(26);
        fab.setTextColor(Color.parseColor("#5ff5d6"));
        fab.setGravity(Gravity.CENTER);
        GradientDrawable oval = new GradientDrawable();
        oval.setShape(GradientDrawable.OVAL);
        oval.setColor(Color.parseColor("#0e2f3f"));
        oval.setStroke(dp(1), Color.parseColor("#1c4456"));
        fab.setBackground(oval);
        fab.setElevation(dp(8));
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMore();
            }
        });
        FrameLayout.LayoutParams fabLp = new FrameLayout.LayoutParams(
                dp(52), dp(52), Gravity.BOTTOM | Gravity.END);
        fabLp.setMargins(0, 0, dp(16), dp(24));
        root.addView(fab, fabLp);

        setContentView(root);
    }

    private GradientDrawable pill(String color) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.RECTANGLE);
        g.setCornerRadius(dp(24));
        g.setColor(Color.parseColor(color));
        return g;
    }

    private void showSites() {
        new AlertDialog.Builder(this)
                .setTitle("ওয়েব")
                .setItems(SITE_NAMES, new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int which) {
                        hidePanel();
                        prefs.edit().putString("lastUrl", SITE_URLS[which]).apply();
                        web.loadUrl(SITE_URLS[which]);
                    }
                })
                .show();
    }

    private void showMore() {
        final CharSequence[] items = new CharSequence[]{
                "🎤 মাইক",
                "🎚 মিক্সার",
                desktop ? "Desktop mode: ON  (tap to turn OFF)" : "Desktop mode: OFF  (tap to turn ON)",
                "🔄 Reload"
        };
        new AlertDialog.Builder(this)
                .setItems(items, new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int which) {
                        if (which == 0) {
                            openPanel("popup.html");
                        } else if (which == 1) {
                            openPanel("mixer.html");
                        } else if (which == 2) {
                            desktop = !desktop;
                            prefs.edit().putBoolean("desktop", desktop).apply();
                            applyUa();
                            web.reload();
                        } else {
                            web.reload();
                        }
                    }
                })
                .show();
    }

    private void openPanel(String file) {
        panelBox.setVisibility(View.VISIBLE);
        panel.loadUrl("file:///android_asset/popup/" + file);
    }

    private void hidePanel() {
        panelBox.setVisibility(View.GONE);
        panel.loadUrl("about:blank");
    }

    // ------------------------------------------------------------------ WebViews

    private void setupMainWebView() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        defaultUa = s.getUserAgentString();
        applyUa();

        web.setBackgroundColor(Color.parseColor("#04121a"));
        web.addJavascriptInterface(new MainBridge(), "SSBridge");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String u = request.getUrl().toString();
                if (u.startsWith("http://") || u.startsWith("https://")) return false;
                return true; // block fb-messenger:// intent:// etc. so we stay in the app
            }

            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap icon) {
                injectedThisLoad = false;
                inject(view);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (url != null && url.startsWith("http")) {
                    prefs.edit().putString("lastUrl", url).apply();
                }
                inject(view);
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int p) {
                if (p >= 30 && !injectedThisLoad) {
                    injectedThisLoad = true;
                    inject(view);
                }
            }

            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        handlePermission(request);
                    }
                });
            }

            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb,
                                             FileChooserParams params) {
                if (pendingFile != null) pendingFile.onReceiveValue(null);
                pendingFile = cb;
                try {
                    startActivityForResult(params.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    pendingFile = null;
                    return false;
                }
                return true;
            }
        });
    }

    private void setupPanelWebView() {
        WebSettings s = panel.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        panel.setBackgroundColor(Color.parseColor("#04121a"));
        panel.addJavascriptInterface(new PanelBridge(), "SSPanel");
        panel.setWebViewClient(new WebViewClient());
        panel.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        handlePermission(request);
                    }
                });
            }
        });
    }

    private void applyUa() {
        String ua = defaultUa == null ? "" : defaultUa;
        ua = ua.replace("; wv", "");
        if (desktop) {
            ua = ua.replaceAll("\\(Linux; Android[^)]*\\)", "(X11; Linux x86_64)").replace(" Mobile", "");
        }
        WebSettings s = web.getSettings();
        s.setUserAgentString(ua);
        s.setUseWideViewPort(desktop);
        s.setLoadWithOverviewMode(desktop);
    }

    private boolean hostAllowed(String url) {
        if (url == null) return false;
        String host;
        try {
            host = Uri.parse(url).getHost();
        } catch (Exception e) {
            return false;
        }
        if (host == null) return false;
        for (String h : ALLOWED_HOSTS) {
            if (host.equals(h) || host.endsWith("." + h)) return true;
        }
        return false;
    }

    private String readAsset(String name) {
        try {
            InputStream in = getAssets().open(name);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            in.close();
            return out.toString("UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    private void inject(WebView view) {
        if (view == null || !hostAllowed(view.getUrl())) return;
        if (injectJs == null) {
            injectJs = readAsset("bridge.js") + "\n;" + readAsset("core/injector.js")
                    + "\n;" + readAsset("mixer.js") + "\n;";
        }
        view.evaluateJavascript(injectJs
                + "window.__ssMixer&&window.__ssMixer.cmd({t:'lib',items:" + libJson() + "});", null);
    }

    private void runInMain(final String js) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (web != null) web.evaluateJavascript(js, null);
            }
        });
    }

    // ------------------------------------------------------------------ permissions + audio

    private boolean hasPerm(String p) {
        return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED;
    }

    private void handlePermission(PermissionRequest req) {
        String origin = req.getOrigin() == null ? "" : req.getOrigin().toString();
        if (!origin.startsWith("file:") && !hostAllowed(origin)) {
            req.deny();
            return;
        }
        List<String> need = new ArrayList<String>();
        for (String r : req.getResources()) {
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r) && !hasPerm(Manifest.permission.RECORD_AUDIO)) {
                need.add(Manifest.permission.RECORD_AUDIO);
            }
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r) && !hasPerm(Manifest.permission.CAMERA)) {
                need.add(Manifest.permission.CAMERA);
            }
        }
        if (need.isEmpty()) {
            grant(req);
        } else {
            pendingRequest = req;
            requestPermissions(need.toArray(new String[0]), REQ_PERM);
        }
    }

    private void grant(PermissionRequest req) {
        try {
            req.grant(req.getResources());
        } catch (Exception ignored) {
        }
        startCallAudio();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == REQ_PERM && pendingRequest != null) {
            PermissionRequest r = pendingRequest;
            pendingRequest = null;
            boolean any = false;
            for (int g : results) if (g == PackageManager.PERMISSION_GRANTED) any = true;
            if (any) grant(r); else r.deny();
        }
    }

    /** Hold audio focus during a call so another app (real Messenger) cannot silence us. */
    private void startCallAudio() {
        try {
            if (audioManager == null) audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
            if (Build.VERSION.SDK_INT >= 26) {
                if (focusRequest == null) {
                    focusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                            .setAudioAttributes(new AudioAttributes.Builder()
                                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                                    .build())
                            .setOnAudioFocusChangeListener(focusListener)
                            .setWillPauseWhenDucked(false)
                            .build();
                }
                audioManager.requestAudioFocus(focusRequest);
            } else {
                audioManager.requestAudioFocus(focusListener, AudioManager.STREAM_VOICE_CALL,
                        AudioManager.AUDIOFOCUS_GAIN);
            }
        } catch (Exception ignored) {
        }
    }

    private void resumeCallAudio() {
        runInMain("window.__ssResume&&window.__ssResume();");
    }

    // ------------------------------------------------------------------ media library

    private String kindOf(String name) {
        String n = name.toLowerCase();
        String[] vid = {".mp4", ".mkv", ".mov", ".3gp", ".webm"};
        for (String v : vid) if (n.endsWith(v)) return "video";
        return "audio";
    }

    private JSONArray libJson() {
        JSONArray a = new JSONArray();
        File[] fs = mixDir.listFiles();
        if (fs == null) return a;
        Arrays.sort(fs, new Comparator<File>() {
            @Override
            public int compare(File x, File y) {
                return Long.compare(x.lastModified(), y.lastModified());
            }
        });
        for (File f : fs) {
            String n = f.getName();
            int i = n.indexOf("__");
            if (i <= 0) continue;
            try {
                JSONObject o = new JSONObject();
                o.put("id", n.substring(0, i));
                o.put("name", n.substring(i + 2));
                o.put("kind", kindOf(n));
                a.put(o);
            } catch (Exception ignored) {
            }
        }
        return a;
    }

    private File findMedia(String id) {
        if (id == null || !id.matches("[a-z0-9]+")) return null;
        File[] fs = mixDir.listFiles();
        if (fs == null) return null;
        for (File f : fs) if (f.getName().startsWith(id + "__")) return f;
        return null;
    }

    private String mediaInfo(String id) {
        File f = findMedia(id);
        return "{\"size\":" + (f == null ? 0 : f.length()) + "}";
    }

    private String mediaChunk(String id, int idx) {
        File f = findMedia(id);
        if (f == null) return "";
        try {
            RandomAccessFile r = new RandomAccessFile(f, "r");
            long off = (long) idx * CHUNK;
            if (off >= r.length()) {
                r.close();
                return "";
            }
            int len = (int) Math.min((long) CHUNK, r.length() - off);
            byte[] buf = new byte[len];
            r.seek(off);
            r.readFully(buf);
            r.close();
            return Base64.encodeToString(buf, Base64.NO_WRAP);
        } catch (Exception e) {
            return "";
        }
    }

    private void notifyLibChanged() {
        final String items = libJson().toString();
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (web != null) {
                    web.evaluateJavascript("window.__ssMixer&&window.__ssMixer.cmd({t:'lib',items:" + items + "})", null);
                }
                if (panel != null) {
                    panel.evaluateJavascript("window.onLibChanged&&window.onLibChanged()", null);
                }
            }
        });
    }

    private void importMedia(final Uri u) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                String name = "file";
                long size = -1;
                Cursor c = null;
                try {
                    c = getContentResolver().query(u, null, null, null, null);
                    if (c != null && c.moveToFirst()) {
                        int ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                        int si = c.getColumnIndex(OpenableColumns.SIZE);
                        if (ni >= 0) name = c.getString(ni);
                        if (si >= 0 && !c.isNull(si)) size = c.getLong(si);
                    }
                } catch (Exception ignored) {
                } finally {
                    if (c != null) c.close();
                }
                if (size > MAX_MEDIA_BYTES) {
                    toast(name + " - file is too big (max 40 MB)");
                    return;
                }
                name = name.replaceAll("[\\\\/:*?\"<>|]", "_");
                String id = Long.toString(Math.abs(System.nanoTime()), 36)
                        + Integer.toString(new Random().nextInt(1296), 36);
                File out = new File(mixDir, id + "__" + name);
                try {
                    InputStream in = getContentResolver().openInputStream(u);
                    OutputStream os = new FileOutputStream(out);
                    byte[] buf = new byte[65536];
                    long total = 0;
                    int n;
                    boolean tooBig = false;
                    while (in != null && (n = in.read(buf)) > 0) {
                        total += n;
                        if (total > MAX_MEDIA_BYTES) {
                            tooBig = true;
                            break;
                        }
                        os.write(buf, 0, n);
                    }
                    os.close();
                    if (in != null) in.close();
                    if (tooBig) {
                        out.delete();
                        toast(name + " - file is too big (max 40 MB)");
                        return;
                    }
                } catch (Exception e) {
                    out.delete();
                    toast("Import failed");
                    return;
                }
                notifyLibChanged();
            }
        }).start();
    }

    private void toast(final String msg) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show();
            }
        });
    }

    private void pickMediaFiles() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "audio/*", "video/*", "application/zip",
                "application/x-zip-compressed", "application/octet-stream"});
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(Intent.createChooser(i, "Audio / Video / ZIP"), REQ_MEDIA);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_FILE) {
            if (pendingFile != null) {
                Uri[] r = null;
                if (res == Activity.RESULT_OK && data != null) {
                    r = WebChromeClient.FileChooserParams.parseResult(res, data);
                }
                pendingFile.onReceiveValue(r);
                pendingFile = null;
            }
        } else if (req == REQ_MEDIA && res == Activity.RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                for (int i = 0; i < data.getClipData().getItemCount(); i++) {
                    importMedia(data.getClipData().getItemAt(i).getUri());
                }
            } else if (data.getData() != null) {
                importMedia(data.getData());
            }
        }
    }

    // ------------------------------------------------------------------ JS bridges

    private String storeJson() {
        return prefs.getString("store", "{}");
    }

    /** Used by the web pages (Messenger, Facebook ...). */
    public class MainBridge {
        @JavascriptInterface
        public String getConfig() {
            try {
                JSONObject st = new JSONObject(storeJson());
                JSONObject cfg = st.optJSONObject("micMaximizerConfig");
                return cfg == null ? "{}" : cfg.toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        @JavascriptInterface
        public void ready() {
            lastReady = System.currentTimeMillis();
        }

        @JavascriptInterface
        public String listMedia() {
            return libJson().toString();
        }

        @JavascriptInterface
        public String mediaInfo(String id) {
            return MainActivity.this.mediaInfo(id);
        }

        @JavascriptInterface
        public String mediaChunk(String id, int idx) {
            return MainActivity.this.mediaChunk(id, idx);
        }

        @JavascriptInterface
        public void mixerState(String json) {
            if (json != null) mixerState = json;
        }
    }

    /** Used by the Mic / Mixer panel pages. */
    public class PanelBridge {
        @JavascriptInterface
        public String getStore() {
            return storeJson();
        }

        @JavascriptInterface
        public void setStore(String s) {
            prefs.edit().putString("store", s == null ? "{}" : s).apply();
            runInMain("window.__ssPush&&window.__ssPush();");
        }

        @JavascriptInterface
        public String lastReady() {
            return String.valueOf(lastReady);
        }

        @JavascriptInterface
        public void mixerCmd(String json) {
            runInMain("window.__ssMixer&&window.__ssMixer.cmd(" + json + ")");
        }

        @JavascriptInterface
        public String getMixerState() {
            return mixerState;
        }

        @JavascriptInterface
        public String listMedia() {
            return libJson().toString();
        }

        @JavascriptInterface
        public String mediaInfo(String id) {
            return MainActivity.this.mediaInfo(id);
        }

        @JavascriptInterface
        public String mediaChunk(String id, int idx) {
            return MainActivity.this.mediaChunk(id, idx);
        }

        @JavascriptInterface
        public String fileUrl(String id) {
            File f = findMedia(id);
            return f == null ? "" : "file://" + f.getAbsolutePath();
        }

        @JavascriptInterface
        public void deleteMedia(String id) {
            File f = findMedia(id);
            if (f != null) f.delete();
            notifyLibChanged();
        }

        @JavascriptInterface
        public void pickFiles() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    pickMediaFiles();
                }
            });
        }
    }
}
