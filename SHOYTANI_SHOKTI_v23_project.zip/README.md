# SHOYTANI SHOKTI v23 (মাহির ব্রাউজার কল)

## GitHub থেকে APK বানানোর ধাপ
1. github.com এ লগইন → উপরে ডানে "+" → New repository → নাম: shoytani-shokti → Create repository।
2. "uploading an existing file" চাপুন → ZIP খুলে ভেতরের সব ফাইল/ফোল্ডার (app, .github, build.gradle, settings.gradle, gradle.properties) টেনে দিন → Commit changes।
   (ফোনে হলে ZIP আগে Files অ্যাপে Extract করে নিন; `.github` ফোল্ডার লুকানো থাকলে "Show hidden files" চালু করুন।)
3. Actions ট্যাব → "Build APK" → Run workflow (বা Commit করলেই নিজে চলবে)।
4. ৩-৫ মিনিট পর সবুজ টিক এলে ওই run খুলুন → নিচে Artifacts → SHOYTANI_SHOKTI_v23 নামান → ZIP খুলে APK ইনস্টল করুন।
5. আগের v22 অ্যাপ আগে আনইনস্টল করুন (সাইন আলাদা, তাই আপডেট হবে না)।
